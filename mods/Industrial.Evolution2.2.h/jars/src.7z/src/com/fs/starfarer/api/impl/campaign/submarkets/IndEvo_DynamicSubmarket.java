package com.fs.starfarer.api.impl.campaign.submarkets;

public interface IndEvo_DynamicSubmarket {
    void prepareForRemoval();
}
