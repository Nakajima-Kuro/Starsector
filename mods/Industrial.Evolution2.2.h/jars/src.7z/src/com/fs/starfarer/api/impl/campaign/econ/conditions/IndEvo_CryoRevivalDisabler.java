package com.fs.starfarer.api.impl.campaign.econ.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.plugins.timers.IndEvo_newDayListener;

import static com.fs.starfarer.api.impl.campaign.econ.impl.Cryorevival.getDistancePopulationMult;

public class IndEvo_CryoRevivalDisabler extends BaseMarketConditionPlugin implements IndEvo_newDayListener {

    @Override
    public void onNewDay() {
        boolean hasCryo = getDistancePopulationMult(market.getLocationInHyperspace()) > 0;

        if (!hasCryo && market.hasIndustry("cryorevival")) {
            market.getIndustry("cryorevival").setDisrupted(1);
        }
    }

    public void apply(String id) {
        Global.getSector().getListenerManager().addListener(this, true);
    }

    public void unapply(String id) {
        Global.getSector().getListenerManager().removeListener(this);
    }

    @Override
    public boolean showIcon() {
        return false;
    }
}
