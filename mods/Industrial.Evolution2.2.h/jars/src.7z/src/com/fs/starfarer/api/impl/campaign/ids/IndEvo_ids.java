package com.fs.starfarer.api.impl.campaign.ids;

import com.fs.starfarer.api.Global;

public class IndEvo_ids {
    //factions
    public static final String CONVERTERS_FACTION_ID = "IndEvo_converters";

    //Memory Keys
    public static final String EMBASSY_LIST = Global.getSettings().getString("IndEvo_embassyList");
    public static final String REVERSE_LIST = Global.getSettings().getString("IndEvo_reverseList");
    public static final String PRINT_LIST = Global.getSettings().getString("IndEvo_printList");
    public static final String SHIPPING_LIST = Global.getSettings().getString("IndEvo_shipingList");
    public static final String ORDER_LIST = Global.getSettings().getString("IndEvo_custOrderList");
    public static final String BUREAU_LIST = Global.getSettings().getString("IndEvo_buerauList");
    public static final String RUIND_LIST = Global.getSettings().getString("IndEvo_ruindList");

    //tags
    public static final String TAG_NEVER_REMOVE_RUINS = "IndEvo_RuinsAlways";

    //Submarkets
    public static final String REPSTORAGE = "IndEvo_RepairStorage";
    public static final String TEMPSTORE = "IndEvo_tempStorage";
    public static final String REQMARKET = "IndEvo_ReqCenterMarket";
    public static final String DECSTORAGE = "IndEvo_DeconstStorage";
    public static final String ENGSTORAGE = "IndEvo_EngStorage";
    public static final String SHAREDSTORAGE = "IndEvo_SharedStore";

    //Industries
    public static final String ADMANUF = "IndEvo_AdManuf";
    public static final String ADASSEM = "IndEvo_AdAssem";
    public static final String COMFORGE = "IndEvo_ComForge";
    public static final String COMARRAY = "IndEvo_ComArray";
    public static final String ADINFRA = "IndEvo_AdInfra";
    public static final String SCRAPYARD = "IndEvo_ScrapYard";
    public static final String SUPCOM = "IndEvo_SupCom";
    public static final String EMBASSY = "IndEvo_embassy";
    public static final String PIRATEHAVEN = "IndEvo_pirateHaven";
    public static final String SENATE = "IndEvo_senate";
    public static final String REPAIRDOCKS = "IndEvo_dryDock";
    public static final String ACADEMY = "IndEvo_Academy";
    public static final String INTARRAY = "IndEvo_IntArray";
    public static final String REQCENTER = "IndEvo_ReqCenter";
    public static final String ENGHUB = "IndEvo_EngHub";
    public static final String HULLFORGE = "IndEvo_HullForge";
    public static final String DECONSTRUCTOR = "IndEvo_HullDecon";
    public static final String LAB = "IndEvo_ResLab";
    public static final String BEACON = "IndEvo_Lighthouse";
    public static final String RIFTGEN = "IndEvo_RiftGen";
    public static final String RUINS = "IndEvo_Ruins";
    public static final String RUINFRA = "IndEvo_RuinedInfra";
    public static final String PORT = "IndEvo_PrivatePort";
    public static final String CHAMELION = "IndEvo_ChamelionIndustry";

    public static final String PIRATEHAVEN_SECONDARY = "IndEvo_pirateHavenSecondary";
    public static final String COMMERCE = "commerce";

    //conditions
    public static final String COND_RUINS = "IndEvo_RuinsCondition";
    public static final String COND_PIRATES = "IndEvo_pirate_subpop";
    public static final String COND_CRYODISABLE = "IndEvo_CryoRevivalDisabler";
    public static final String COND_RESSOURCES = "IndEvo_ressCond";
    public static final String COND_INFRA = "IndEvo_RuinedInfra";
    public static final String COND_LOG_CORE = "IndEvo_LogCoreCond";

    //Hullmods
    public static final String DEFECTS_LOW = "IndEvo_print_low";
    public static final String DEFECTS_MED = "IndEvo_print_med";
    public static final String DEFECTS_HIGH = "IndEvo_print_high";
    public static final String PRINTING_INDICATOR = "IndEvo_auto";

    //Entities
    public static final String INTARRAY_ENTITY_TAG = "IndEvo_intArray";
    public static final String INTARRAY_ENTITY = "IndEvo_int_array";
    public static final String PRISTINE_INTARRAY_ENTITY ="IndEvo_pristine_int_array";
    public static final String ARSENAL_ENTITY = "IndEvo_arsenalStation";
    public static final String LAB_ENTITY = "IndEvo_orbitalLaboratory";

}
