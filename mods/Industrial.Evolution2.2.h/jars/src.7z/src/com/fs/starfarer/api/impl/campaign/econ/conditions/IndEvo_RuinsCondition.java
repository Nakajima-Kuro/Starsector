package com.fs.starfarer.api.impl.campaign.econ.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.IndEvo_IndustryHelper;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.IndEvo_ids;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static com.fs.starfarer.api.impl.campaign.econ.impl.derelicts.IndEvo_Ruins.INDUSTRY_ID_MEMORY_KEY;

public class IndEvo_RuinsCondition extends BaseHazardCondition {

    public static final Logger log = Global.getLogger(IndEvo_RuinsCondition.class);

    @Deprecated
    protected final String pickerSeed = "$IndEvo_ruinsPickerSeed";

    public void apply(String id) {
        super.apply(id);

        if(!market.getMemoryWithoutUpdate().getBoolean("$isPlanetConditionMarketOnly")
                && !isRuinsConditionSet()
                && market.getFaction() != null
                && !market.getFactionId().equals("neutral")
                && !market.isPlanetConditionMarketOnly()){

            setUpgradeSpec(market.getPlanetEntity());
            addRuinsIfNeeded();
        }
    }

    public void unapply(String id) {
        super.unapply(id);
    }

    @Override
    public void advance(float amount) {
        removeConditionIfRuinsNotPresent();
    }

    private static Map<String, Integer> getCurrentPresenceMap() {
        //counts the currently present ruin-industries in the sector and returns a list with amounts
        Map<String, Float> indMap = getbaseWeightedIndustryMap();
        Map<String, Integer> countMap = new HashMap<>();

        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            //if it has ruins, get the set upgrade and increment
            if (market.getMemoryWithoutUpdate().contains(INDUSTRY_ID_MEMORY_KEY)) {
                String id = market.getMemoryWithoutUpdate().getString(INDUSTRY_ID_MEMORY_KEY);

                IndEvo_IndustryHelper.addOrIncrement(countMap, id, 1);
                continue;
            }

            //else, check if a derelictInd is present
            for (Industry ind : market.getIndustries()) {
                String id = ind.getId();

                if (indMap.containsKey(id)) {
                    IndEvo_IndustryHelper.addOrIncrement(countMap, id, 1);
                }
            }
        }
        return countMap;
    }

    private static boolean isDeconOrForge(String id){
        return id != null && (id.equals(IndEvo_ids.DECONSTRUCTOR) || id.equals(IndEvo_ids.HULLFORGE));
    }

    public static void setUpgradeSpec(PlanetAPI planet) {
        if(planet == null || planet.getMarket() == null) return;

        MarketAPI market = planet.getMarket();
        MemoryAPI memory = market.getMemoryWithoutUpdate();

        if (memory.contains(INDUSTRY_ID_MEMORY_KEY)) return;

        //if the system has a hullForge/decon, this will always resolve to the opposite
        //if system has another unset cond, resolve into either decon or forge with 70% chance
        for(MarketAPI m : Misc.getMarketsInLocation(market.getStarSystem())){
            if(m.getId().equals(market.getId())) continue;

            MemoryAPI localMem = m.getMemoryWithoutUpdate();

            if(m.hasCondition(IndEvo_ids.COND_RUINS)){

                if(localMem.contains(INDUSTRY_ID_MEMORY_KEY) && isDeconOrForge(localMem.getString(INDUSTRY_ID_MEMORY_KEY))){
                    String id = localMem.getString(INDUSTRY_ID_MEMORY_KEY);
                    id = id.equals(IndEvo_ids.DECONSTRUCTOR) ? IndEvo_ids.HULLFORGE : IndEvo_ids.DECONSTRUCTOR;

                    market.getMemoryWithoutUpdate().set(INDUSTRY_ID_MEMORY_KEY, id);
                    log.info("Second planet found, overriding into " + id);
                    return;
                } else {
                    if(new Random().nextFloat() >= 0.2f){
                        String id = new Random().nextBoolean()? IndEvo_ids.DECONSTRUCTOR : IndEvo_ids.HULLFORGE;
                        market.getMemoryWithoutUpdate().set(INDUSTRY_ID_MEMORY_KEY, id);
                        log.info("Second planet found, overriding into " + id);
                        return;
                    } else break;
                }
            }
        }

        //otherwise,
        String chosenIndustry;
        Map<String, Float> weightMap = new HashMap<>();
        Map<String, Integer> currentPresenceMap = getCurrentPresenceMap();
        WeightedRandomPicker<String> industryIdPicker = new WeightedRandomPicker<>();

        //make a wonderful weighted chance for each industry
        for (Map.Entry<String, Float> s : getbaseWeightedIndustryMap().entrySet()) {
            if (currentPresenceMap.containsKey(s.getKey())) {
                //if there is an industry of that hullSize already, reduce the chance of a second one appearing exponentially
                log.info("Chance for " + s.getKey() + " at " + (s.getValue() * (Math.pow(0.5f, currentPresenceMap.get(s.getKey()) * 1.5f))) + "for " + currentPresenceMap.get(s.getKey()) + " entries");

                weightMap.put(s.getKey(), (float) (s.getValue() * (Math.pow(0.5f, currentPresenceMap.get(s.getKey()) * 1.5f))));

            } else {
                log.info("Chance for " + s.getKey() + " at " + (s.getValue()));

                weightMap.put(s.getKey(), s.getValue());
            }
        }

        for (Map.Entry<String, Float> entry : weightMap.entrySet()) {
            industryIdPicker.add(entry.getKey(), entry.getValue());
        }

        //remove riftGen if the planet has rings
        if(market.hasCondition(Conditions.SOLAR_ARRAY) || IndEvo_IndustryHelper.planetHasRings(planet) || (planet.isGasGiant())){
            industryIdPicker.remove(IndEvo_ids.RIFTGEN);
        }

        Random random = new Random(Misc.getSalvageSeed(planet));
        chosenIndustry = industryIdPicker.pick(random);

        market.getMemoryWithoutUpdate().set(INDUSTRY_ID_MEMORY_KEY, chosenIndustry);
    }

    private static Map<String, Float> getbaseWeightedIndustryMap(){
        Map<String, Float> indMap = new HashMap<>();
        indMap.put(IndEvo_ids.LAB, 1.4f);
        indMap.put(IndEvo_ids.DECONSTRUCTOR, 1.1f);
        indMap.put(IndEvo_ids.HULLFORGE, 1.2f);
        indMap.put(IndEvo_ids.RIFTGEN, 0.6f);
        //indMap.put(IndEvo_ids.BEACON, 0.1f);

        return indMap;
    }

    private boolean isRuinsConditionSet(){
        MemoryAPI memory = market.getMemoryWithoutUpdate();
        String ruinsConditionSet = "$IndEvo_ruinsPlaced_" + market.getId();

        return memory.getBoolean(ruinsConditionSet);
    }

    private void addRuinsIfNeeded(){
        if(market == null) return;

        log.info("Adding ruins to " + market.getName());
        market.addIndustry(IndEvo_ids.RUINS);
        setRuinsCondition();
        Global.getSector().getEconomy().tripleStep();

        //Global.getSector().getScripts().add(new IndEvo_TriggerTripleStep());
    }

    private void setRuinsCondition(){
        MemoryAPI memory = market.getMemoryWithoutUpdate();
        String ruinsConditionSet = "$IndEvo_ruinsPlaced_" + market.getId();

        memory.set(ruinsConditionSet, true);
    }

    private void removeConditionIfRuinsNotPresent(){
        if(!market.getMemoryWithoutUpdate().getBoolean("$isPlanetConditionMarketOnly")
                && isRuinsConditionSet()
                && !market.hasIndustry(IndEvo_ids.RUINS)
                && !market.getFactionId().equals("neutral")
                && !market.isPlanetConditionMarketOnly()){

            log.info("Removing RuinsCondition on " + market.getName());
            market.removeSpecificCondition(condition.getIdForPluginModifications());
        }
    }

    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        super.createTooltipAfterDescription(tooltip, expanded);
        MemoryAPI memory = market.getMemoryWithoutUpdate();

        tooltip.addPara("Restoring them to working order could give %s unlike any others.",
                10f,
                Misc.getTextColor(),
                Misc.getHighlightColor(),
                new String[]{"access to exotic technologies"});

        if (memory.contains(INDUSTRY_ID_MEMORY_KEY) && market.getSurveyLevel().equals(MarketAPI.SurveyLevel.FULL)) {
            String s = "Scans of the site strangely report nothing of note.";

            switch (memory.getString(INDUSTRY_ID_MEMORY_KEY)){
                case IndEvo_ids.LAB:
                    s = "Initial scans show a massive, largely underground complex filled with arcane energy signatures.";
                    break;
                case IndEvo_ids.DECONSTRUCTOR:
                    s = "The first scan results misreported the presence of an enormous weapons array - but it seems to be pointed at itself for some reason.";
                    break;
                case IndEvo_ids.HULLFORGE:
                    s = "Deep scans report a strange similarity to energy patterns usually emitted by a dormant Nanoforge.";
                    break;
                case IndEvo_ids.RIFTGEN:
                    s = "All scans of the site come back with nonsensical results - some even entirely misreport the location of the ruins.";
                    break;
            }

            tooltip.addPara(s,
                    10f,
                    Misc.getTextColor());
        }
    }
}