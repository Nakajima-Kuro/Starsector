package com.fs.starfarer.api.plugins.derelicts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.listeners.SurveyPlanetListener;
import com.fs.starfarer.api.impl.campaign.econ.conditions.IndEvo_RuinsCondition;
import com.fs.starfarer.api.impl.campaign.econ.impl.TechMining;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.IndEvo_ids;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.util.Misc;

import java.util.Random;

import static com.fs.starfarer.api.impl.campaign.ids.Tags.*;

public class IndEvo_RuinsManager {
    private static void log(String Text) {
        Global.getLogger(IndEvo_RuinsManager.class).info(Text);
    }

    public static void placeRuinedInfrastructure(){
        if (!Global.getSettings().getBoolean("Enable_Indevo_Derelicts")) return;

        float amount = 0;
        for (StarSystemAPI s : Global.getSector().getStarSystems()) {
            if(Global.getSector().getEconomy().getStarSystemsWithMarkets().contains(s)) continue;

            if (s == null || s.getPlanets().isEmpty()) continue;
            boolean ruinsTheme = s.getTags().contains(THEME_RUINS) || s.getTags().contains(THEME_DERELICT);

            int currentCount = 0;

            //iterate through the planets
            for (PlanetAPI p : s.getPlanets()) {
                if (p.isStar() || p.getMarket() == null || TechMining.getTechMiningRuinSizeModifier(p.getMarket()) <= 0f) continue;

                float chance = TechMining.getTechMiningRuinSizeModifier(p.getMarket()) * 0.5f;
                chance *= ruinsTheme ? 1.5 : 1;
                chance /= 1 + (currentCount * 0.3f);

                Random r = new Random(Misc.getSalvageSeed(p));
                if (r.nextFloat() <= chance) {
                    p.getMarket().addCondition(IndEvo_ids.COND_INFRA);
                    log(IndEvo_ids.COND_INFRA.toLowerCase() + " found on " + p.getName() + " (" + p.getTypeId() + ") in " + s.getName());
                    currentCount++;
                    amount++;
                }
            }
        }

        log("Total ruined Infra in sector: " + amount);
    }

    public static class ResolveRuinsToUpgradeListener implements SurveyPlanetListener {

        @Override
        public void reportPlayerSurveyedPlanet(PlanetAPI planet) {
            if (planet.getMarket().hasCondition(IndEvo_ids.COND_RUINS)) {
                IndEvo_RuinsCondition.setUpgradeSpec(planet);
            }
        }
    }

    public static void forceCleanCoreRuins(){
        for (StarSystemAPI s : Global.getSector().getStarSystems()) {
            if (s == null || s.getPlanets().isEmpty()) continue;

            for (PlanetAPI p : s.getPlanets()) {
                if (p.isStar() || p.getMarket() == null) continue;

                MarketAPI pMarket = p.getMarket();

                if (pMarket.hasCondition(IndEvo_ids.COND_RUINS)) {
                    if (Misc.getMarketsInLocation(p.getContainingLocation()).size() > 0
                            || s.getTags().contains(THEME_CORE)
                            || s.getTags().contains(THEME_CORE_POPULATED)
                            || s.getTags().contains(THEME_CORE_UNPOPULATED)) {

                        if(!pMarket.getFactionId().equals("player")){
                            pMarket.removeCondition(IndEvo_ids.COND_RUINS);

                            if(pMarket.isPlanetConditionMarketOnly()) continue;

                            pMarket.removeIndustry(IndEvo_ids.RUINS, null, false);
                            pMarket.removeIndustry(IndEvo_ids.HULLFORGE, null, false);
                            pMarket.removeIndustry(IndEvo_ids.DECONSTRUCTOR, null, false);
                            pMarket.removeIndustry(IndEvo_ids.RIFTGEN, null, false);
                            pMarket.removeIndustry(IndEvo_ids.LAB, null, false);
                        }
                    }
                }
            }
        }
    }

    public static void placeIndustrialRuins() {
        boolean forbidden = !Global.getSettings().getBoolean("Enable_Indevo_Derelicts");

        float amount = 0;
        float total = 0;

        //count ruinsConditions + clean all conditions from planets that are not remnant themed
        for (StarSystemAPI s : Global.getSector().getStarSystems()) {
            if (s == null || s.getPlanets().isEmpty()) continue;

            boolean remnant = s.getTags().contains(THEME_REMNANT);

            int currentCount = 0;
            Random r;

            //iterate through the planets
            for (PlanetAPI p : s.getPlanets()) {
                if (p.isStar() || p.getMarket() == null) continue;

                //if it has the tag, skip it
                if(p.getTags().contains(IndEvo_ids.TAG_NEVER_REMOVE_RUINS)){
                    if(!p.getMarket().hasCondition(IndEvo_ids.COND_RUINS)) p.getMarket().addCondition(IndEvo_ids.COND_RUINS);
                    seedRuinsIfNeeded(p);
                    continue;
                }

                if (remnant) total++;

                float mod = 0.2f;
                if (s.getTags().contains(Tags.THEME_REMNANT_SUPPRESSED)) mod = 0.55f;
                if (s.getTags().contains(Tags.THEME_REMNANT_RESURGENT)) mod = 0.85f;

                //log("mod " + mod);

                if (p.getMarket().hasCondition(IndEvo_ids.COND_RUINS)) {
                    if (forbidden || !remnant || Misc.getMarketsInLocation(p.getContainingLocation()).size() > 0) {
                        p.getMarket().removeCondition(IndEvo_ids.COND_RUINS);
                    } else {
                        currentCount++;

                        switch (currentCount) {
                            case 1:
                                r = new Random();
                                if (r.nextFloat() < mod) {
                                    seedRuinsIfNeeded(p);
                                    log(IndEvo_ids.COND_RUINS.toLowerCase() + " found on " + p.getName() + " (" + p.getTypeId() + ") in " + s.getName());
                                    amount++;
                                } else {
                                    p.getMarket().removeCondition(IndEvo_ids.COND_RUINS);
                                }
                                break;
                            case 2:

                                r = new Random();
                                if (r.nextFloat() < (mod * 0.70f)) {
                                    seedRuinsIfNeeded(p);
                                    log(IndEvo_ids.COND_RUINS.toLowerCase() + " found on " + p.getName() + " (" + p.getTypeId() + ") in " + s.getName() + " - Second Planet");
                                    amount++;
                                } else {
                                    p.getMarket().removeCondition(IndEvo_ids.COND_RUINS);
                                }

                                break;
                            case 3:
                            default:
                                p.getMarket().removeCondition(IndEvo_ids.COND_RUINS);
                        }
                    }
                }
            }
        }

        log("Total RuinConditions found in sector: " + amount);
        log("Total Remnant themed planets found in sector: " + total);
    }

    private static void seedRuinsIfNeeded(PlanetAPI p) {
        //seed ruins if it doesn't have them
        boolean ruins = false;
        for (MarketConditionAPI condition : p.getMarket().getConditions()) {
            if (condition.getId().contains("ruins_")) ruins = true;
        }

        if (!ruins) {
            p.getMarket().addCondition(Conditions.RUINS_SCATTERED);
        }
    }
}
