package com.fs.starfarer.api.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.IndEvo_IndustryHelper;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.EconomyTickListener;
import com.fs.starfarer.api.campaign.listeners.ListenerManagerAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseInstallableItemEffect;
import com.fs.starfarer.api.impl.campaign.econ.impl.ItemEffectsRepo;
import com.fs.starfarer.api.impl.campaign.econ.impl.installableItemPlugins.IndEvo_SpecialItemEffectsRepo;
import com.fs.starfarer.api.impl.campaign.fleets.IndEvo_ShippingManager;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.contacts.ContactIntel;
import com.fs.starfarer.api.plugins.ambassadorPlugins.IndEvo_ambassadorPersonManager;
import com.fs.starfarer.api.plugins.converters.IndEvo_ConverterRepResetScript;
import com.fs.starfarer.api.plugins.derelicts.IndEvo_DerelictStationPlacer;
import com.fs.starfarer.api.plugins.derelicts.IndEvo_RuinsManager;
import com.fs.starfarer.api.plugins.derelicts.IndEvo_SalvageSpecialAssigner;
import com.fs.starfarer.api.plugins.economy.IndEvo_PartsManager;
import com.fs.starfarer.api.plugins.notifications.IndEvo_depositMessage;
import com.fs.starfarer.api.plugins.timers.IndEvo_TimeTracker;
import com.fs.starfarer.api.plugins.timers.IndEvo_raidTimeout;
import com.fs.starfarer.api.plugins.update.IndEvo_ModUpdater;
import com.fs.starfarer.api.plugins.update.IndEvo_NewGameIndustryPlacer;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.json.JSONObject;

import java.util.Map;

import static com.fs.starfarer.api.impl.campaign.rulecmd.academyRules.IndEvo_AcademyVariables.ACADEMY_MARKET_ID;

public class IndEvo_modPlugin extends BaseModPlugin {
    private static void log(String Text) {
        Global.getLogger(IndEvo_modPlugin.class).info(Text);
    }

    @Override
    public void onGameLoad(boolean newGame) {
        //IndEvo_DerelictStationPlacer.addDebugStation();
        //IndEvo_SuperStructureManager.addDysonSwarmEntity(Global.getSector().getStarSystem("corvus"));

        if (Global.getSettings().getBoolean("IndEvo_CommerceBalanceChanges")) overrideVanillaItemImp();

        createAcademyMarket();

        //updateVersionIfNeeded(newGame);
        setListenersIfNeeded();
        setScriptsIfNeeded();

        IndEvo_PartsManager.applyRessourceCondToAllMarkets();
        IndEvo_SpecialItemEffectsRepo.addItemEffectsToVanillaRepo();

        loadTransientMemory();
    }

    public static int DEALMAKER_INCOME_PERCENT_BONUS = 25;

    @Override
    public void onNewGameAfterEconomyLoad() {
        super.onNewGameAfterEconomyLoad();

        IndEvo_RuinsManager.forceCleanCoreRuins();
        IndEvo_NewGameIndustryPlacer.run();
        createAcademyMarket();

        if (Global.getSettings().getBoolean("Enable_Indevo_Derelicts")) {
            new IndEvo_DerelictStationPlacer().init();
            new IndEvo_SalvageSpecialAssigner().init();
        }

        IndEvo_RuinsManager.placeRuinedInfrastructure();
        IndEvo_RuinsManager.placeIndustrialRuins();

        IndEvo_ConverterRepResetScript.resetConverterRep();
    }

    private void createAcademyMarket() {
        if (Global.getSector().getEconomy().getMarket(ACADEMY_MARKET_ID) == null
                && Global.getSector().getEntityById("station_galatia_academy") != null) {

            log("Creating academy market");

            MarketAPI market = Global.getFactory().createMarket(ACADEMY_MARKET_ID, "Galatia Academy", 3);
            market.setHidden(true);
            market.getMemoryWithoutUpdate().set(ContactIntel.NO_CONTACTS_ON_MARKET, true);

            market.setFactionId(Factions.INDEPENDENT);
            market.setSurveyLevel(MarketAPI.SurveyLevel.NONE);
            market.addCondition(Conditions.POPULATION_3);

            market.addIndustry(Industries.POPULATION);
            market.addIndustry(IndEvo_ids.ACADEMY);

            market.setPrimaryEntity(Global.getSector().getEntityById("station_galatia_academy"));
            Global.getSector().getEconomy().addMarket(market, false);
        }
    }

    private void loadTransientMemory() {
        IndEvo_IndustryHelper.getVPCItemSet();
        IndEvo_IndustryHelper.getVayraBossShips();
        IndEvo_IndustryHelper.getPrismBossShips();

        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.EMBASSY_LIST);
        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.ORDER_LIST);
        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.PRINT_LIST);
        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.REVERSE_LIST);
        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.SHIPPING_LIST);
        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.BUREAU_LIST);
        IndEvo_IndustryHelper.getCSVSetFromMemory(IndEvo_ids.RUIND_LIST);
    }

    private void setListenersIfNeeded() {
        IndEvo_SpecialItemEffectsRepo.initEffectListeners();

        ListenerManagerAPI l = Global.getSector().getListenerManager();

        if (!l.hasListenerOfClass(IndEvo_PartsManager.RessCondApplicator.class)) l.addListener(new IndEvo_PartsManager.RessCondApplicator(), true);
        if (!l.hasListenerOfClass(IndEvo_RuinsManager.ResolveRuinsToUpgradeListener.class)) l.addListener(new IndEvo_RuinsManager.ResolveRuinsToUpgradeListener(), true);
        if (!l.hasListenerOfClass(IndEvo_depositMessage.class)) l.addListener(new IndEvo_depositMessage(), true);
        if (!l.hasListenerOfClass(IndEvo_ambassadorPersonManager.class)) l.addListener(new IndEvo_ambassadorPersonManager(), true);
        if (!l.hasListenerOfClass(IndEvo_raidTimeout.class)) l.addListener(new IndEvo_raidTimeout(), true);
        if (!l.hasListenerOfClass(IndEvo_PartsManager.PartsCargoInterceptor.class)) l.addListener(new IndEvo_PartsManager.PartsCargoInterceptor(), true);
        if (!l.hasListenerOfClass(IndEvo_ConverterRepResetScript.class)) l.addListener(new IndEvo_ConverterRepResetScript(), true);

        if (!l.hasListenerOfClass(IndEvo_ShippingManager.class)) {
            IndEvo_ShippingManager srm = new IndEvo_ShippingManager();
            l.addListener(srm);
            Global.getSector().getMemoryWithoutUpdate().set(IndEvo_ShippingManager.KEY, srm);
        }

        Global.getSector().addTransientListener(new IndEvo_PartsManager.PartsLootAdder(false));
        Global.getSector().addTransientListener(new IndEvo_ambassadorPersonManager.checkAmbassadorPresence());
    }

    private void setScriptsIfNeeded() {
        //Scripts:
        if (!Global.getSector().hasScript(IndEvo_TimeTracker.class)) {
            Global.getSector().addScript(new IndEvo_TimeTracker());
        }
    }

    public void overrideVanillaItemImp() {
        ItemEffectsRepo.ITEM_EFFECTS.put(Items.DEALMAKER_HOLOSUITE, new BaseInstallableItemEffect(Items.DEALMAKER_HOLOSUITE) {
            public void apply(Industry industry) {
                industry.getMarket().getIncomeMult().modifyPercent(spec.getId(), DEALMAKER_INCOME_PERCENT_BONUS,
                        Misc.ucFirst(spec.getName().toLowerCase()));
            }

            public void unapply(Industry industry) {
                industry.getMarket().getIncomeMult().unmodifyPercent(spec.getId());
            }

            protected void addItemDescriptionImpl(Industry industry, TooltipMakerAPI text, SpecialItemData data,
                                                  InstallableIndustryItemPlugin.InstallableItemDescriptionMode mode, String pre, float pad) {
                text.addPara(pre + "Colony income increased by %s.",
                        pad, Misc.getHighlightColor(),
                        "" + (int) DEALMAKER_INCOME_PERCENT_BONUS + "%");
            }
        });

        for (MarketAPI m : Global.getSector().getEconomy().getMarketsCopy()) {
            if (m.hasIndustry(IndEvo_ids.COMMERCE)) {

                Industry ind = m.getIndustry(IndEvo_ids.COMMERCE);
                SpecialItemData special = ind.getSpecialItem();
                String aiCore = ind.getAICoreId();
                boolean improved = ind.isImproved();
                boolean isBuilding = ind.isBuilding();
                float buildProgress = ind.getBuildOrUpgradeProgress();

                m.removeIndustry(IndEvo_ids.COMMERCE, null, false);
                m.addIndustry(IndEvo_ids.COMMERCE);

                ind = m.getIndustry(IndEvo_ids.COMMERCE);

                if(isBuilding) {
                    ind.startBuilding();
                    ((BaseIndustry) ind).setBuildProgress(buildProgress);
                }

                ind.setSpecialItem(special);
                ind.setAICoreId(aiCore);
                ind.setImproved(improved);
            }
        }
    }
}
