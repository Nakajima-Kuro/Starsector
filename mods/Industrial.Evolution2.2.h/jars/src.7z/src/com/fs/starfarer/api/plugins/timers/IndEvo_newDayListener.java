package com.fs.starfarer.api.plugins.timers;

public interface IndEvo_newDayListener {
    void onNewDay();
}
